import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import Home from './pages/Home'
import Projects from './pages/Projects'
import Skills from './pages/Skills'
import Education from './pages/Education'
import Internships from './pages/Internships'
import Certificates from './pages/Certificates'
import Awards from './pages/Awards'
import Organizations from './pages/Organizations'
import Contact from './pages/Contact'

function Navbar({theme, setTheme}){
  return (
    <nav className={'fixed w-full z-50 backdrop-blur bg-white/60 dark:bg-gray-900/60 border-b'}>
      <div className='max-w-6xl mx-auto flex items-center justify-between p-4'>
        <Link to='/' className='text-2xl font-bold text-indigo-600 dark:text-indigo-300'>Pinjari Raziya</Link>
        <div className='flex items-center gap-6'>
          <Link to='/projects' className='hover:underline'>Projects</Link>
          <Link to='/skills' className='hover:underline'>Skills</Link>
          <Link to='/education' className='hover:underline'>Education</Link>
          <Link to='/contact' className='hover:underline'>Contact</Link>

          {/* Theme toggle */}
          <button aria-label='Toggle theme' onClick={() => setTheme(theme==='dark'?'light':'dark')} className='p-2 rounded-full border'>
            {theme==='dark' ? '🌙' : '🌞'}
          </button>
        </div>
      </div>
    </nav>
  )
}

export default function App(){
  const [theme, setTheme] = useState('light')
  useEffect(()=>{
    if(theme==='dark'){ document.documentElement.classList.add('dark') } else { document.documentElement.classList.remove('dark') }
  },[theme])

  return (
    <Router>
      <div className='min-h-screen bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-black transition-colors'>
        <Navbar theme={theme} setTheme={setTheme} />
        <div className='pt-28'>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/projects' element={<Projects />} />
            <Route path='/skills' element={<Skills />} />
            <Route path='/education' element={<Education />} />
            <Route path='/internships' element={<Internships />} />
            <Route path='/certificates' element={<Certificates />} />
            <Route path='/awards' element={<Awards />} />
            <Route path='/organizations' element={<Organizations />} />
            <Route path='/contact' element={<Contact />} />
          </Routes>
        </div>
      </div>
    </Router>
  )
}
