import React from 'react'
import { motion } from 'framer-motion'

const orgs = [
  'Robotics Club, GCET, Member',
  'National Service Scheme, Volunteer',
  'Art of Living Foundation, Volunteer',
  'Youth Empowerment Skills Program (YES+), Coordinator'
]

export default function Organizations(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-4xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Organizations</h2>
      <ul className='space-y-2'>
        {orgs.map((o,idx)=>(<li key={idx} className='p-3 bg-white dark:bg-gray-800 rounded shadow'>{o}</li>))}
      </ul>
    </motion.div>
  )
}
