import React from 'react'
import { motion } from 'framer-motion'
import p1 from '../assets/project1.jpg'
import p2 from '../assets/project2.jpg'
import p3 from '../assets/project3.jpg'
import p4 from '../assets/project4.jpg'

const projects = [
  { title: 'Fashion Fuse', desc: 'AI/ML garment customization platform', img: p1, github: 'https://github.com/raziya5h1' },
  { title: 'Student Relocation Assistant', desc: 'Flask + ML relocation assistant', img: p2, github: 'https://github.com/raziya5h1' },
  { title: 'VIPRON 360', desc: 'IoT weather-responsive vehicle protection', img: p3, github: 'https://github.com/raziya5h1' },
  { title: 'Aqua Recharge', desc: 'Groundwater recharge automation', img: p4, github: 'https://github.com/raziya5h1' },
]

export default function Projects(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-6xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Projects</h2>
      <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
        {projects.map((p,idx)=>(
          <motion.div key={idx} whileHover={{scale:1.02}} className='bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden'>
            <img src={p.img} alt={p.title} className='w-full h-48 object-cover parallax' />
            <div className='p-4'>
              <h3 className='text-xl font-semibold'>{p.title}</h3>
              <p className='mt-2 text-sm'>{p.desc}</p>
              <div className='mt-4 flex gap-2'>
                <a href={p.github} target='_blank' rel='noreferrer' className='px-3 py-1 bg-indigo-600 text-white rounded'>GitHub</a>
                <a href='#' className='px-3 py-1 border rounded'>Live</a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}
