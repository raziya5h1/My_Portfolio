import React from 'react'
import { motion } from 'framer-motion'

const certs = [
  'Research Opportunities in Computer Science — By IITH',
  'AI and Data Scientist — By Oneroadmap',
  'AniCAT Certificate — by Naukiri NCAT',
  'Certified System Administrator — ServiceNow',
  'Certified Application Developer — ServiceNow',
  'PCEP: Entry-Level Python Programmer Certification — Python Institute',
  'AI Tools Certification — Be10X',
  'Digital Forensics Workshop — Hacker the House',
  'IEEE IoT Versa — IEEE'
]

export default function Certificates(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-4xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Certificates</h2>
      <ul className='space-y-2'>
        {certs.map((c,idx)=>(<li key={idx} className='p-3 bg-white dark:bg-gray-800 rounded shadow'>{c}</li>))}
      </ul>
    </motion.div>
  )
}
