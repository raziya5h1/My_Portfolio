import React from 'react'
import { motion } from 'framer-motion'

export default function Education(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-4xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Education</h2>
      <div className='space-y-4'>
        <div className='p-4 bg-white dark:bg-gray-800 rounded-lg shadow'>
          <h3 className='font-semibold'>Bachelor of Technology, Computer Science and Engineering</h3>
          <p className='text-sm'>2022 – 2026 | CGPA: 8.9</p>
        </div>
        <div className='p-4 bg-white dark:bg-gray-800 rounded-lg shadow'>
          <h3 className='font-semibold'>Intermediate, MPC</h3>
          <p className='text-sm'>2020 – 2022 | 94.7%</p>
        </div>
        <div className='p-4 bg-white dark:bg-gray-800 rounded-lg shadow'>
          <h3 className='font-semibold'>Secondary School Certificate (SSC)</h3>
          <p className='text-sm'>2020 | 93.1%</p>
        </div>
      </div>
    </motion.div>
  )
}
