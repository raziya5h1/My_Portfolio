import React from 'react'
import { motion } from 'framer-motion'
import profile from '../assets/profile.jpg'
import resume from '../assets/Pinjari_Raziya_Resume.pdf'

export default function Home(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-6xl mx-auto p-8'>
      <div className='grid grid-cols-1 md:grid-cols-3 gap-8 items-center'>
        <div className='col-span-1 flex justify-center'>
          <motion.img 
  src={profile}
  alt="profile"
  whileHover={{ scale: 1.05 }}
  transition={{ duration: 0.3 }}
  className="
    w-64 h-64 
    rounded-full 
    shadow-2xl 
    border-4 border-indigo-300 
    object-cover 
    object-center 
  "
/>

        </div>
        <div className='col-span-2'>
          <h1 className='text-4xl font-bold text-indigo-600'>Pinjari Raziya</h1>
          <p className='mt-2 text-lg'>B.Tech CSE Student | AI/ML | IoT | Cybersecurity | Web Development</p>
          <p className='mt-4'>Innovative B.Tech CSE student passionate about AI/ML, IoT, Cybersecurity, and Web Development. Proven track record at T-Hub, SIH, and hackathons for building real-world prototypes.</p>

          <div className='mt-6 flex gap-4'>
            <a 
  href="https://drive.google.com/file/d/10Y092QGYyo5BrDb2UcPSRiI7-uSWDQFu/view?usp=sharing" 
  target="_blank"
  rel="noopener noreferrer"
  className='px-4 py-2 bg-indigo-600 text-white rounded shadow hover:opacity-90'
>
  📄 Download Resume
</a>

            <a href='mailto:pinjariraziya4@gmail.com' className='px-4 py-2 border rounded'>✉️ Email</a>
            <a href='https://github.com/raziya5h1' target='_blank' rel='noreferrer' className='px-4 py-2 border rounded'>GitHub</a>
          </div>
        </div>
      </div>

      <section className='mt-12 grid grid-cols-1 md:grid-cols-3 gap-6'>
        <motion.div whileHover={{y:-6}} className='p-6 bg-white dark:bg-gray-800 shadow rounded-lg'>
          <h3 className='text-xl font-semibold'>Skills</h3>
          <p className='mt-2'>Machine Learning, DSA, Networking, DBMS, Big Data</p>
        </motion.div>
        <motion.div whileHover={{y:-6}} className='p-6 bg-white dark:bg-gray-800 shadow rounded-lg'>
          <h3 className='text-xl font-semibold'>Internships</h3>
          <p className='mt-2'>Cantiliver, Edvedha, Eduskills, Talentrek, Fundsaduits</p>
        </motion.div>
        <motion.div whileHover={{y:-6}} className='p-6 bg-white dark:bg-gray-800 shadow rounded-lg'>
          <h3 className='text-xl font-semibold'>Awards</h3>
          <p className='mt-2'>Design Thinking Winner, Team Management, Documentation Awards</p>
        </motion.div>
      </section>
    </motion.div>
  )
}
