import React from 'react'
import { motion } from 'framer-motion'

const skillGroups = {
  'Machine Learning': 'Regression, Classification, Clustering, Decision Trees',
  'Operating Systems': 'Processes, Threads, Memory Management, File Systems',
  'Computer Networks': 'TCP/IP, HTTP/HTTPS, Socket Programming',
  'DSA': 'Arrays, Linked Lists, Trees, Graphs, Heaps',
  'Database Systems': 'ER Models, SQL, Indexing, Transactions',
  'Big Data': 'Hadoop, Hive, Spark, MapReduce'
}

export default function Skills(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-6xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Technical Skills</h2>
      <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
        {Object.entries(skillGroups).map(([k,v],i)=>(
          <motion.div key={i} whileHover={{y:-6}} className='p-4 bg-white dark:bg-gray-800 rounded-lg shadow'>
            <h3 className='font-semibold'>{k}</h3>
            <p className='text-sm mt-2'>{v}</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}
