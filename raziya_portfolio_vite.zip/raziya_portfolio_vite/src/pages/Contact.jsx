import React from 'react'
import { motion } from 'framer-motion'

export default function Contact(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-2xl mx-auto p-8 text-center'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-4'>Contact</h2>
      <p className='text-lg'>Email: <strong>pinjariraziya4@gmail.com</strong></p>
      <p className='mt-2 text-lg'>Phone: <strong>9347234489</strong></p>
      <p className='mt-2 text-lg'>Location: <strong>Telangana, India</strong></p>
      <div className='mt-6 flex justify-center gap-4'>
        <a href='https://github.com/raziya5h1' target='_blank' rel='noreferrer' className='px-4 py-2 bg-indigo-600 text-white rounded'>GitHub</a>
        <a href='https://linkedin.com/in/raziya-p-497845255' target='_blank' rel='noreferrer' className='px-4 py-2 border rounded'>LinkedIn</a>
      </div>
    </motion.div>
  )
}
