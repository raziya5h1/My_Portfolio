import React from 'react'
import { motion } from 'framer-motion'

const interns = [
  { title: 'Fundsaduits – Mobile App Developer', date: '09/2025 – 10/2025' },
  { title: 'Talentrek – Artificial Intelligence', date: '05/2025 – 08/2025' },
  { title: 'Cantiliver – Machine Learning', date: '05/2024 – 06/2024' },
  { title: 'Eduskills – AI & ML', date: '04/2024 – 06/2024' },
  { title: 'Edvedha – Cybersecurity Intern', date: '01/2024 – 06/2024' }
]

export default function Internships(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-4xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Internships</h2>
      <div className='space-y-4'>
        {interns.map((i,idx)=>(
          <div key={idx} className='p-4 bg-white dark:bg-gray-800 rounded-lg shadow'>
            <h3 className='font-semibold'>{i.title}</h3>
            <p className='text-sm'>{i.date}</p>
          </div>
        ))}
      </div>
    </motion.div>
  )
}
