import React from 'react'
import { motion } from 'framer-motion'

const awards = [
  'Winner – Design Thinking Project EXPO',
  'Elections Appreciation Certificate – GHMC',
  'Kickstart-BLITZ Certificate – T-Hub',
  'Best Team Management Award',
  'Excellent Presentation Skills',
  'Creative Thinking',
  'Best Documentation',
  'Fastest Typing Compliment'
]

export default function Awards(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-4xl mx-auto p-8'>
      <h2 className='text-3xl font-bold text-indigo-600 mb-6'>Awards</h2>
      <ul className='space-y-2'>
        {awards.map((a,idx)=>(<li key={idx} className='p-3 bg-white dark:bg-gray-800 rounded shadow'>{a}</li>))}
      </ul>
    </motion.div>
  )
}
