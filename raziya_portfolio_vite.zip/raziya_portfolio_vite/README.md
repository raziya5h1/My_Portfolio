# Raziya Portfolio (Vite + React + Tailwind + Framer Motion)

This is a ready-to-run React + Vite portfolio project generated for Pinjari Raziya.
It includes:
- Multi-page routing with React Router
- Theme toggle (light/dark)
- Embedded resume PDF (in `/src/assets/Pinjari_Raziya_Resume.pdf`)
- Project images & GitHub links
- Framer Motion animations and simple parallax/floating effects
- Tailwind CSS setup

## How to run locally
1. Install dependencies:

```bash
npm install
```

2. Run dev server:

```bash
npm run dev
```

3. Build for production:

```bash
npm run build
```

4. Preview build:

```bash
npm run preview
```

> This project uses Tailwind CSS. If you want to customize, edit `tailwind.config.cjs` and `src/index.css`.

## Notes
- Replace `src/assets/profile.jpg` with your real photo (keep the same filename or update imports accordingly).
- Update project images in `src/assets/` and GitHub/Live links inside `src/pages/Projects.jsx`.
- The `package.json` included is for reference. Run `npm install` to install listed dependencies.
